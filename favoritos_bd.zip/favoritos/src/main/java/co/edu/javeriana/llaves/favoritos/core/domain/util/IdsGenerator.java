package co.edu.javeriana.llaves.favoritos.core.domain.util;

public abstract class IdsGenerator {

    public abstract String generateId();
}
