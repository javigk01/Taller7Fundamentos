package co.edu.javeriana.llaves.favoritos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FavoritosApplication {

	public static void main(String[] args) {
		SpringApplication.run(FavoritosApplication.class, args);
	}

}
