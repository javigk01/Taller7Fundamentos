package co.edu.javeriana.llaves.favoritos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FavoritosApplicationTests {

	@Test
	void contextLoads() {
	}

}
